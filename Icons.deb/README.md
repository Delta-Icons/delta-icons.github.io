<p align="center">
	<div style="text-align: center; margin: 120px 0">
	<img src="https://github.com/Delta-Icons/android/raw/master/delta-logo.png" alt="">
</div>
</p>

# Delta Icons
Matted out icon pack for custom Android launchers and iOS.

## Contributing
I'll try to put some work into automating a submission System once i get the time to do so. In the meantime please refer to my [mail adress](mailto:leif.niem@gmail.com) and use the Palette included in the Android repo for your ideas.

Licensed under [Creative Commons Attribution-NonCommercial-NoDerivatives License 4.0](https://creativecommons.org/licenses/by-nc-nd/4.0/)